# creating a file
f=open("file1.txt",'w')
print("name : ",f.name)
print("Mode : ",f.mode)
print("readable : ",f.readable())
print("writable : ",f.writable())
print("Is Closed : ",f.closed)
f.close()
print("Is Closed : ",f.closed)