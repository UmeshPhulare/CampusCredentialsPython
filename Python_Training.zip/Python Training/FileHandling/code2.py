import logging as log
log.basicConfig(filename='file2.txt',level=log.DEBUG)
try:
  n1=int(input())
  n2=int(input())
  print(n1//n2)
except (ZeroDivisionError,ValueError) as msg:
  print("Error : ",msg)
  log.exception(msg)