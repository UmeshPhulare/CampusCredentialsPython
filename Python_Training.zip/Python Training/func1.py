#------------- positional argument --------------------
# def info(firstname,lastname):
#     print("First Name : ",firstname)
#     print("Last Name : ",lastname)

# info("Umesh", "Phulare")


# --------------multiple return values ---------------
# def arithmetic(a,b):
#     add=a+b
#     sub=a-b
#     mul=a*b
#     div=a//b
#     mod=a%b
#     return add,sub,mul,div,mod

# print("Result type = ",type(arithmetic(20,10)))
# print("Result = ",arithmetic(20,10))



# ------------keyword argument---------------
# def info(fname,lname):
#     print("First Name : ",fname)
#     print("Last Name : ",lname)
# info(lname="Phulare",fname="Umesh")

# fname=input("Enter 1st Name : ")
# lname=input("Enter last Name : ")
# info(fname,lname)



#------------ default argument ----------------
# def func(city="Nagpur"):
#     print("I am from ",city)
# func("Mumbai")
# func()


# def func(name):
#     for i in name:
#         print(i)
# func("UmeshPhulare")



# variable length/no argument
# def name(*name):
#     # print(type(name))
#     print(name)
# name("Umesh",101,True)


# a=[1,2,3,4,5,6,7,8,9]
# a[::2]=10,20,30,40,50,60
# print(a)


# a=[1,2,3,4,5]
# print(a[3:0:-1])


# def func(value,values):
#     var=1
#     values[0]=44
# t=3
# v=[1,2,3]
# func(t,v)
# print(t,v[0])


# data =[ [[1,2],[3,4]] , [[5,6],[7,8]]]
# def fun(m):
#     v=m[0][0]
#     print(v)
#     print(m)
#     for row in m:
#         for element in row:
#             if v < element : v=element
#     return v
# print(fun(data[0])) 



# arr=[[1,2,3,4],[4,5,6,7],[8,9,10,11],[12,13,14,15]]
# for i in range(4):
#     print(arr[i].pop())


# def func(i,values=[]):
#     values.append(i)
#     print(values)
# func(1)
# func(2)
# func(3)


# arr=[1,2,3,4,5,6]
# for i in range(1,6):
#     arr[i-1]=arr[i]
# print(arr)

# fl1=['apple','berry','cherry','papaya']
# fl2=fl1   #sharing same adddress space
# fl3 = fl1[:]    # copying elemts of fl1 to fl3 with diff address space
# fl2[0]='guava'
# fl3[1]='kiwi'

# sum=0
# for i in (fl1,fl2,fl3):
#     if i[0] =='guava':
#         sum+=1
#     if i[1]=='kiwi':
#         sum+=20
# print(fl1)
# print(fl2)
# print(fl3)
# print(sum)

# arr=[1,2,4,5]
# for i in range(4):
#     print(arr[i],"\t",arr[-(i+1)])

# for i in range(1,6):
#     if i!=3:
#         print(i,"\t",(6-i))

# for i,j in zip(range(1,6),range(5,0,-1)):
#     if i!=j:
#         print(i,'\t',j)



# str1='programming'
# str2=''
# for i in str1:
#     if i not in str2:
#         str2+=i
# print(str2)

# l1=['a','b']
# for i in l1 : print(i,end='')


# for i,j in zip(range(1,11),range(1,11)):
#     print(i*j,end="\t")
    
# for i in range(1,11):
#     for j in range(1,11):
#         print(i*j,end='\t')
#     print()
# print("----------------------------------------------------------")

# for i in range(11,21):
#     for j in range(1,11):
#         print(i*j,end='\t')
#     print()


# n=int(input("Range : "))
# for i in range(1,n+1):
#     for j in range(1,1+i):
#         print(chr(64+i),end='\t')
#     print()

# palindorme
# str1=input("enter string : ")
# if str1 == str1[::-1]:
#     print("It is a Palindrome .")
# else:
#     print("Not a Palindrome .")


# count consonant and vowels
# str1=input()
# vowel=0
# consonant=0
# for i in str1.lower():
#     if i in ['a','e','i','o','u']:
#         vowel+=1
#     else:
#         consonant+=1
# print("Vowel : ",vowel)
# print("Consonant : ",consonant)


# anagram
# str1=input()
# str2=input()
# if sorted(list(str1)) == sorted(list(str2)):
#     print("Its an Anagram")
# else:
#     print("Its not an Anagram")


#panagram
# str1=input().upper().strip()
# flag=True
# for i in range(65,91):
#     if chr(i) not in str1:
#         flag=False
# if flag:
#     print("PANAGRAM")
# else:
#     print("Not a PANAGRAM")


# count no. of substring
# str1=input()
# str2=''
# cnt=0
# count=0
# for i in str1:
    # if i not in str2:                      not done
#         str2+=i
#         cnt+=1
#     else:
        
#         count+=1
# print(count)

# s='umesh phulare'
# print(s.find('phulare'))
# print(s.find('abc'))

# s="john",'jani','janardan'
# print(' and '.join(s))

# s="hi hello how are you"
# print(s.swapcase())
# print(s.title())
# print(s.capitalize())



# l1=[5,7,8,3,7,8,9,2,3,7,3]
# l2=[]
# for i in range(len(l1)):
#     j=1+i
#     key=l1[i]                           not done (count the total elements which repeated )
#     while j < len(l2):
#         if key==l1[j]:
#             if key not in l2:
#                 l2.append(key)
#         j+=1
# print(len(l2))
    


# input 
# 5
# 10 11 7 12 14
#output   12/

# sum=0
# l1=[]
# n=int(input("Range : "))
# for i in range(n): l1.append(int(input(f"Enter Value {i+1} : ")))
# for i in range(len(l1)-1):
#     sum+=abs(l1[i]-l1[i+1])
# print("Sum : ",sum)

# count the no of spaces
# s=input()
# print(s.count(" "))


# a4b3c2 code
# s=input()
# s1=''
# for i in set(s):
#     s1+=i+str(s.count(i))
# print(s1)
# ----------
# d1=dict()
# for i in s:
#     d1[i]=s.count(i)
# for key,val in d1.items():
#     print(key+str(val),end='')


# addition of values in dictionary
# d1={'A':10,'B':20,'C':30,'D':40}
# sum=0
# for i in d1.values():
#     sum+=i
# print("Sum : ",sum)

# d1['mob']=342323
# print(d1)
# print(d1.pop('mob'))
# print(d1)


# sorting dict values/keys                                   not done
# d1={'C':3,'B':2,'A':1}
# l1=list(d1.keys())
# # l1=l1.sort()
# d2={d1[i]:i for i in l1}
# print(d1)


# --------------------------EXCEPTION HANDLING -------------------


# try:
#     n1=int(input("Enter value : "))
#     n2 = int(input("Enter 2nd value : "))
#     print(n1/n2)
# except ValueError as message:
#     print("Wrong Input Type : ",message)
# except ZeroDivisionError as message:
#     print("Cannot divide by 0 : ",message)
# except:
#     print("Normal any other Error")

for i in range(5):
    for k in range(5,i)



    