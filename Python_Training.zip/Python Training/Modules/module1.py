def welcome(fname,lname):
    print("First Name : ",fname)
    print("Last Name : ",lname)

def square(a):
    print("Area of Square : ",a*a)

def login(user,pwd):
    if user==pwd:
        print("Login Successful")
    else:
        print("Invalid Credentials")

PI=3.14
