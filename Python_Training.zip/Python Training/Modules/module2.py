import module1 as m                    #using m as alias name
m.welcome('Umesh','Phulare')
m.square(10)
m.login('umesh','umesh')
r=int(input('Enter Radius : '))
print('Circumference of Circle : ',(2*m.PI*r))
