def csfirstyearsubject():
    print("F1")
    print("F2")
    print("F3")
    print("F4")