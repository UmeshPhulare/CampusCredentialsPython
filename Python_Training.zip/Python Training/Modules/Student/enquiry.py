fullpath = 'C:\\Users\\Umesh Phulare\\Desktop\\Umesh\\Python Training\\Modules'
import sys
sys.path.append(fullpath)

from CSBranch.cs_firstyear import csfirstyearsubject
csfirstyearsubject()
