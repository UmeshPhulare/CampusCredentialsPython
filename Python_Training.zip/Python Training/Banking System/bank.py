# from abc import ABC,abstractmethod
# class Person:
#     def __init__(self):
#         self.name=''
#         self.address=''
#         self.mobile_no=''
#     def get_details(self):
#         print('Name : ',self.name)
#         print('Address : ',self.address)
#         print('Mobile Number : ',self.mobile_no)
    
# class Account(ABC):

class Student:
  student=[]
  def __init__(self,name):
    self.name=name
stu=Student('umesh')
Student.student.append(stu)
