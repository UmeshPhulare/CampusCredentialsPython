from abc import ABC, abstractmethod
class Person:
    def __init__(self):
        self.name = input("Enter Your Name : ")
        self.address = input("Enter Your Address : ")
        self.phno = input("Enter Your Phone Number : ")
    
    def get_details(self):
        print("Name : ",self.name)
        print("Address : ",self.address)
        print("Mobile Number  : ",self.phno)


class Account(ABC):
    def __init__(self,accno,owner,balance):
        self.accno = accno
        self.owner = owner
        self.balance = balance
    @abstractmethod
    def deposit(amount):
        pass
    @abstractmethod
    def withdraw(amount):
        pass

    def get_balance(amount):
        print("Balance : ",self.balance)

    def show_account_details(amount):
        print("Account Number : ",self.accno)
        print("Account Owner : ",self.owner)
        print("Account Balance : ",self.balance)


class Customer(Person):                 #all accounts linked to a particular customer
    accounts=[]
    def __init__(self,):
        pass
    def add_account(self,account):
        pass
    def remove_account(self,account_no):
        pass
    def get_account_summary(self):
        pass
    
class Admin(Person):
    admins={}
    def __init__(self):
        super().__init__()
        self.id=int(input("Enter Your Admin ID : "))
        Admin.admins[self.id]=self

    def approve_account(self,customer,account):
        pass
    def view_all_customers(self):
        pass


class Transaction(ABC):
    transaction_id=''
    transaction_type=''
    transacted_amount=''
    transaction_date=''
    def get_transaction_details(self):
        print("Transaction ID : ",self.transaction_id)
        print("Transaction Type : ",self.transaction_type)
        print("Transacted Amount : ",self.transacted_amount)
        print("Transaction Date & Time : ",self.transaction_date)

class Savings(Account):
    def __init__(self):
        pass

class Business(Account):
    def __init__(self):
        pass

class Bank():
    def __init__(self):
        pass

# --------------------------------------------------------------------------------------------------------------------

def adminLogin():
    id=int(input("Enter your Admin ID : "))
    if id not in Admin.adminIDs:
        return False
    else:
        choice=0
        admin=Admin.admins[id]
        while choice!=3:
            print("Logged In Successfully !!\n\n1.Account Requests\n2. View Customers\n3.Exit")
            choice = int(input("Enter Your Choice : "))
            if choice==1:
                pass
            elif choice==2:
                pass
            elif choice==3:
                print("Exitting Admin Page....")
                break
            else:
                print("Enter Appropriate Option !")
    return True

def adminRegistration():
    new_admin = Admin()
    print('Admin Registered Successfully !!')
    return


def customerLogin():
    cust = int(input("Enter Your Customer ID : "))



# --------------------------------------------------------------------------------------------------------------------


print("Welcom to the Banking System !!")
choice=0
while choice!=5:
    
    print("\n1.Customer Login \n2. New Customer \n3.Admin Login \n4. New Admin Registration \n5. Exit")
    ch = int(input("Enter your choice : "))
    if ch==1:        
        customerlogin()
    elif ch==2:
        pass:
    elif ch==3:
        if not adminLogin():
            continue
    elif ch==4:
        adminRegistration()

    print("\n1.Create A New Account \n2.Balance Enquiry \n3.Deposit Amount \n.4Withdraw Amount \n5.Exit")
    choice=int(input("Enter Your Choice : "))
    
    if choice == 1:
        personal=Person()
        
