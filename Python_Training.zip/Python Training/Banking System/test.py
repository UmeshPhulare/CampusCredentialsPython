import csv

class Test:
    # questions=[]
    # option1=[]
    # option2=[]
    # option3=[]
    # option4=[]
    # answer=[]

    def test(self):
        self.r=0
        self.w=0
        file=open('questions.csv','r')
        ques=csv.reader(file)
        data=list(ques)
        for line in data:
            print("Question. ",line[0])
            print("1) ",line[1])
            print("2) ",line[2])
            print("3) ",line[3])
            print("4) ",line[4])
            self.ans=int(input("Enter Your Correct Option Number (Only 1) : "))
            if self.ans==int(line[5]):
                self.r+=1
            else:
                self.w+=1
        return self.r,self.w
        file.close()

class Student(Test):
    students=[]
    testGiven=False
    def __init__(self):
        self.name=''
        self.rno=0
        self.clg=''
        self.dept=''
        self.right=0
        self.wrong=0

    def set_info(self,name,rno,clg,dept):
        self.name=name
        self.rno=rno
        self.clg=clg
        self.dept=dept
        self.right=0
        self.wrong=0

    def give_exam(self):
        self.right,self.wrong = self.test()
        Student.testGiven=True
        print("Exam Done !!")

    def result(self):
        if not Student.test:
            print("1st give the Test !!!")
            return
        print("Name : ",self.name)
        print("Roll no  : ",self.rno)
        print("College Name : ",self.clg)
        print("Department Name : ",self.dept)
        print("Correct Answers : ",self.right)
        print("Incorrect Answers : ",self.wrong)
        file=open('questions.csv','r')
        ques=csv.reader(file)
        data=list(ques)
        file.close()
        self.score=(100*self.right)/len(data)
        print("Score : ",self.score,'%')

class Admin(Test):
    adminslist=['AD101','AD102','AD201']
    def add_question(self):
        ch=0
        file=open('questions.csv','a',newline='')
        ques=csv.writer(file)
        while ch!=2:
            print('\n1.Add Question\n2.Exit')
            ch=int(input("Enter Your Choice : "))
            if ch==1:
                question=input("Enter Your Question : ")
                opt1=input("Enter Option 1 : ")
                opt2=input("Enter Option 2 : ")
                opt3=input("Enter Option 3 : ")
                opt4=input("Enter Option 4 : ")
                correct_opt=int(input("Enter Correct Option No : "))
                print("\nQuestion Added Successfully !!\n")
                # csv file
                ques.writerow([question,opt1,opt2,opt3,opt4,correct_opt])
                # Test.questions.append(question)
                # Test.option1.append(opt1)
                # Test.option2.append(opt2)
                # Test.option3.append(opt3)
                # Test.option4.append(opt4)
                # Test.answer.append(correct_opt)
            elif ch==2: 
                file.close()
                return
            else:
                print("Enter Appropriate Input")
    

if __name__ == "__main__":
    
    print("Welcome !!")
    choice =0
    stud=Student()
    while choice !=5:
        print('\n1. Add Student Info\n2.Admin Add Question\n3.Give The Exam\n4.Display result\n5. Exit')
        choice=int(input('Enter Your  choice : '))
        if choice==1:
            name=input("Enter Name : ")
            rno=int(input("Enter Roll No : "))
            clg=input("Enter College Name : ")
            dept=input("Enter Department : ")
            stud.set_info(name,rno,clg,dept)
            Student.students.append(stud)
            print("Student Profile Created !!")
        elif choice==2:
            admin=Admin()
            id=input('Enter your admin ID : ')
            if id not in Admin.adminslist:
                print("Invalid ADmin ID !!")
                continue
            else:
                admin.add_question()
                
        elif choice==3:
            n=input('Enter Your Name : ')
            if n != stud.name:
                print("Invalid Name or Student Not Registered !!")
                stud.give_exam()
        
        elif choice==4:
            stud.result()
        
        elif choice==5:
            break
        else:
            print("Enter Appropriate Option !!!")
            